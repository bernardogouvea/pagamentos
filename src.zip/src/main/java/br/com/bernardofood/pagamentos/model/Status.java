package br.com.bernardofood.pagamentos.model;

public enum Status {

    CRIADO,
    CONFIRMADO,
    CANCELADO
}
