package br.com.bernardofood.pagamentos.repository;

import br.com.bernardofood.pagamentos.model.Pagamento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagamentoRepository extends JpaRepository<Pagamento,Long> {

}